---
title: Other
weight: 8
---

Schema Diagram:

You can find a schema diagram at https://drawsql.app/templates/laravel-permission
