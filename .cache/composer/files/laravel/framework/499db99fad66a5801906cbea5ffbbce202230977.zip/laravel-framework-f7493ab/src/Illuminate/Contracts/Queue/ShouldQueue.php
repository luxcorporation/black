<?php

namespace Illuminate\Contracts\Queue;

interface ShouldQueue
{
    //
}
